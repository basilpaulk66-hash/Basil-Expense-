# Basil Expense – Android app

## Steps (use a computer)
1. Make a free account at github.com and create a **New repository** (name: basil-expense).
2. Click **uploading an existing file**. Drag ALL files and folders from this project
   (including the hidden `.github` folder, `www`, `package.json`, `capacitor.config.json`). Click **Commit changes**.
3. Open the **Actions** tab. Wait 5–8 minutes for **Build Android APK** to turn green
   (or click it, then **Run workflow**).
4. Open the finished run, scroll to **Artifacts**, download **basil-expense-apk**, unzip it.
5. Send `app-debug.apk` to your phone and install it (allow "install unknown apps" when asked).

## First use
- Open **More** tab, paste your AI key (from console.anthropic.com) and tap **Save key**.
  The key is needed for Bill scan and AI tips. The AI usage is charged to that key.
- Allow Camera when the phone asks.
